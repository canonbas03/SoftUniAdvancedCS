﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            Person p2 = new Person(20);
            Person p3 = new Person("Jorge",25);
           
        }
    }
}
