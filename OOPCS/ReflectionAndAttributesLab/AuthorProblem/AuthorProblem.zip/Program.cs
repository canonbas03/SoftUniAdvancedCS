﻿namespace AuthorProblem
{
    internal class Program
    {
        [Author("Dzhan")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
