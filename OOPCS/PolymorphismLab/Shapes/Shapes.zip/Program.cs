﻿namespace Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Rectangle rectangle = new Rectangle(5, 5);
            //Console.WriteLine(rectangle.CalculatePerimeter());
            //Console.WriteLine(rectangle.CalculateArea());
        }
    }
}
