﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Bob Marley";
            p1.Age = 69;
        }
    }
}
