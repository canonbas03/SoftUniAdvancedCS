﻿namespace BoxOfT
{
    public class Box<T>
    {
        private List<T> list;
        private int _count;

        public int Count => this._count;
        public Box()
        {
            list = new List<T>();
            this._count = 0;
        }
        public void Add(T element)
        {
            this.list.Add(element);
            this._count++;
        }

        public T Remove()
        {
            if(_count <= 0)
            {
                throw new ArgumentOutOfRangeException("No more elements!!!");
            }
            T element = this.list[_count - 1];
            this._count--;
            return element;

        }
    }
}
